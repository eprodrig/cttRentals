<?php
defined('BASEPATH') or exit('No se permite acceso directo');

class TAdminModel extends Model
{

    public function __construct()
    {
      parent::__construct();
    }
}