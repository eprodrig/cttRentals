var seccion = '';
$(document).ready(function () {
	pos = 4;
	verifica_usuario();
	busca_sidebar();
});

function busca_sidebar() {}
